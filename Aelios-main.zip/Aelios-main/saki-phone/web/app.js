/**
 * Saki Phone App — Gateway Dashboard
 * Connects to saki-gateway backend API for chat, memory, reminders, and settings.
 */

// ============================================
// SVG Icon Helper
// ============================================
function svgIcon(id, extraClass = '') {
  return `<svg class="icon${extraClass ? ' ' + extraClass : ''}"><use href="#i-${id}"/></svg>`;
}

// ============================================
// Main Application Class
// ============================================
class SakiPhoneApp {
  constructor() {
    this.currentPage = 'home';
    this.previousPage = null;
    this.chatHistory = [];
    this.isTyping = false;
    this.gatewayConfig = null;
    this.healthData = null;
    this.currentMemoryCategory = '';
    this.init();
  }

  async apiFetch(url, options = {}) {
    const opts = {
      cache: 'no-store',
      ...options,
      headers: {
        ...(options.headers || {}),
      },
    };
    const res = await fetch(url, opts);
    if (res.status === 401) {
      const error = new Error('AUTH_REQUIRED');
      error.code = 'AUTH_REQUIRED';
      throw error;
    }
    return res;
  }

  // ------------------------------------------
  // Initialization
  // ------------------------------------------
  async init() {
    this.loadLocalData();
    this.applyTheme(localStorage.getItem('saki_theme') || 'pink');
    this.setupEventListeners();
    this.setupTouchEvents();
    this.startClock();
    this.showHome();
  }

  loadLocalData() {
    try {
      this.chatHistory = JSON.parse(localStorage.getItem('saki_chat_history') || '[]');
    } catch {
      this.chatHistory = [];
    }
  }

  saveChatHistory() {
    try {
      // keep last 500 messages
      if (this.chatHistory.length > 500) {
        this.chatHistory = this.chatHistory.slice(-500);
      }
      localStorage.setItem('saki_chat_history', JSON.stringify(this.chatHistory));
    } catch (e) {
      console.warn('Failed to save chat history:', e);
    }
  }

  setupEventListeners() {
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') this.hideModal();
    });

    // Memory search debounce
    const searchInput = document.getElementById('memory-search');
    if (searchInput) {
      let timer = null;
      searchInput.addEventListener('input', () => {
        clearTimeout(timer);
        timer = setTimeout(() => {
          const q = searchInput.value.trim();
          if (q) {
            this.searchMemories(q);
          } else {
            this.renderMemories();
          }
        }, 400);
      });
    }

    // Auto-resize chat input
    const chatInput = document.getElementById('chat-input');
    if (chatInput) {
      chatInput.addEventListener('input', () => {
        chatInput.style.height = 'auto';
        chatInput.style.height = Math.min(chatInput.scrollHeight, 100) + 'px';
      });
    }
  }

  setupTouchEvents() {
    let startX = 0;
    document.addEventListener('touchstart', (e) => {
      startX = e.changedTouches[0].screenX;
    }, { passive: true });
    document.addEventListener('touchend', (e) => {
      const endX = e.changedTouches[0].screenX;
      if (endX - startX > 100 && this.currentPage !== 'home') {
        this.goBack();
      }
    }, { passive: true });
  }

  startClock() {
    const update = () => {
      const el = document.getElementById('status-time');
      if (el) {
        const now = new Date();
        el.textContent = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      }
    };
    update();
    setInterval(update, 30000);
  }

  // ------------------------------------------
  // Navigation
  // ------------------------------------------
  switchPage(name) {
    this.previousPage = this.currentPage;
    this.currentPage = name;

    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const target = document.getElementById(`page-${name}`);
    if (target) {
      target.classList.add('active');
      target.style.animation = 'slideIn 0.3s ease-out';
    }

    this.updateBottomNav(name);

    switch (name) {
      case 'home': this.renderHome(); break;
      case 'chat': this.renderChat(); this.ensureChatInput(); break;
      case 'memory': this.renderMemories(); break;
      case 'reminders': this.renderReminders(); break;
      case 'settings': this.renderSettings(); break;
    }
  }

  updateBottomNav(page) {
    document.querySelectorAll('.tab-item').forEach(item => {
      item.classList.toggle('active', item.dataset.page === page);
    });
  }

  goBack() {
    if (this.previousPage && this.previousPage !== this.currentPage) {
      this.switchPage(this.previousPage);
    } else {
      this.showHome();
    }
  }

  showHome() { this.switchPage('home'); }
  showChat() { this.switchPage('chat'); }
  showMemory() { this.switchPage('memory'); }
  showReminders() { this.switchPage('reminders'); }
  showSettings() { this.switchPage('settings'); }

  // ------------------------------------------
  // Home Page
  // ------------------------------------------
  async renderHome() {
    let partnerName = 'TA';
    let online = false;
    let memoryCount = 0;
    let tools = [];

    try {
      const res = await this.apiFetch('/health');
      if (res.ok) {
        const data = await res.json();
        this.healthData = data;
        const state = data.state || {};
        partnerName = state.persona || 'TA';
        online = true;
        memoryCount = state.memory_count || 0;
        tools = state.enabled_tools || [];
      }
    } catch (err) {
      online = false;
      if (err?.code === 'AUTH_REQUIRED') {
        const statusText = document.getElementById('home-status-text');
        if (statusText) statusText.textContent = '需要重新登录';
      }
    }

    // Partner name
    const nameEl = document.getElementById('home-partner-name');
    if (nameEl) nameEl.textContent = partnerName;
    const chatName = document.getElementById('chat-partner-name');
    if (chatName) chatName.textContent = partnerName;
    const previewName = document.getElementById('preview-name');
    if (previewName) previewName.textContent = partnerName;

    // Status
    const dot = document.getElementById('home-status-dot');
    if (dot) {
      dot.className = 'status-dot ' + (online ? 'online' : 'offline');
    }
    const statusText = document.getElementById('home-status-text');
    if (statusText) statusText.textContent = online ? '在线' : '离线';

    // Memory count
    const memEl = document.getElementById('home-memory-count');
    if (memEl) memEl.textContent = `${memoryCount} 条记忆`;

    // Reminder count
    let reminderCount = 0;
    try {
      const rRes = await fetch('/api/reminders');
      
      if (rRes.ok) {
        const rData = await rRes.json();
        reminderCount = (rData.items || []).length;
      }
    } catch { /* ignore */ }
    const remEl = document.getElementById('home-reminder-count');
    if (remEl) remEl.textContent = reminderCount > 0 ? `${reminderCount} 个提醒` : '无提醒';

    // Tools list
    const toolsList = document.getElementById('home-tools-list');
    if (toolsList) {
      if (tools.length === 0) {
        toolsList.innerHTML = '<div class="empty-text">暂无启用的工具</div>';
      } else {
        toolsList.innerHTML = tools.map(t => `
          <div class="list-item">
            <div class="list-icon">${svgIcon('tool')}</div>
            <div class="list-content">
              <div class="list-title">${this.escapeHtml(t.id || t.name || 'tool')}</div>
              <div class="list-desc">${this.escapeHtml(t.description || '')}</div>
            </div>
          </div>
        `).join('');
      }
    }

    // Chat preview
    const lastAssistant = [...this.chatHistory].reverse().find(m => m.role === 'assistant');
    const previewText = document.getElementById('preview-text');
    if (previewText) {
      previewText.textContent = lastAssistant ? lastAssistant.content.slice(0, 80) : '点击开始聊天...';
    }
  }

  // ------------------------------------------
  // Chat Page
  // ------------------------------------------
  renderChat() {
    const container = document.getElementById('chat-messages');
    if (!container) return;

    if (this.chatHistory.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">${svgIcon('chat', 'icon-xl')}</div>
          <p>开始你们的甜蜜聊天吧</p>
        </div>
      `;
      return;
    }

    container.innerHTML = this.chatHistory.map(msg => {
      if (msg.role === 'system') {
        return `<div class="chat-message system"><div class="system-content">${this.escapeHtml(msg.content)}</div></div>`;
      }
      const isUser = msg.role === 'user';
      const avatar = isUser ? svgIcon('user') : svgIcon('heart');
      const time = msg.timestamp ? this.formatTime(new Date(msg.timestamp)) : '';
      const toolHtml = msg.toolContexts && msg.toolContexts.length > 0
        ? msg.toolContexts.map(tc => `<div class="tool-context-indicator">${svgIcon('tool', 'icon-sm')} ${this.escapeHtml(tc.type || 'tool')}</div>`).join('')
        : '';

      return `
        <div class="chat-message ${isUser ? 'user' : 'assistant'}">
          <div class="message-avatar">${avatar}</div>
          <div class="message-body">
            <div class="message-header">
              <span>${isUser ? '我' : (this.healthData?.state?.persona || 'TA')}</span>
              <span>${time}</span>
            </div>
            ${toolHtml}
            <div class="message-bubble-inner">${this.renderMarkdown(msg.content)}</div>
          </div>
        </div>
      `;
    }).join('');

    this.scrollToBottom(container);
  }

  renderMarkdown(text) {
    let html = this.escapeHtml(text || '');
    return html.replace(/\n/g, '<br>');
  }

  async sendMessage() {
    const input = document.getElementById('chat-input');
    if (!input) return;
    const text = input.value.trim();
    if (!text) return;

    // Add user message
    this.addMessage('user', text);
    input.value = '';
    input.style.height = 'auto';
    this.saveChatHistory();
    this.renderChat();

    // Send to gateway
    this.showTypingIndicator();
    try {
      const res = await fetch('/api/chat/respond', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [{ role: 'user', content: text }]
        })
      });

      if (!res.ok) {
        const errText = await res.text().catch(() => '');
        throw new Error(`${res.status} ${errText.slice(0, 150)}`);
      }

      const data = await res.json();
      const content = data.content || '...';
      const toolContexts = data.tool_contexts || [];

      this.hideTypingIndicator();
      this.addMessage('assistant', content, { toolContexts });
      this.saveChatHistory();
      this.renderChat();
    } catch (err) {
      this.hideTypingIndicator();
      this.showToast(`请求失败: ${err.message}`, 'error');
    }
  }

  handleChatKeydown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      this.sendMessage();
    }
  }

  addMessage(role, content, extra = {}) {
    this.chatHistory.push({
      id: this.generateId(),
      role,
      content,
      timestamp: new Date().toISOString(),
      ...extra
    });
  }

  showTypingIndicator() {
    this.isTyping = true;
    const container = document.getElementById('chat-messages');
    if (!container) return;
    const existing = container.querySelector('.typing-indicator');
    if (existing) return;
    const div = document.createElement('div');
    div.className = 'chat-message assistant typing-indicator';
    div.innerHTML = `
      <div class="message-avatar">${svgIcon('heart')}</div>
      <div class="message-body">
        <div class="message-bubble-inner">
          <div class="typing-dots"><span></span><span></span><span></span></div>
        </div>
      </div>
    `;
    container.appendChild(div);
    this.scrollToBottom(container);
  }

  hideTypingIndicator() {
    this.isTyping = false;
    const el = document.querySelector('.typing-indicator');
    if (el) el.remove();
  }

  ensureChatInput() {
    const area = document.getElementById('chat-input-area');
    if (area) {
      area.style.display = 'flex';
      area.style.visibility = 'visible';
    }
  }

  showChatMenu() {
    this.showModal('聊天', `
      <div style="padding:8px 0;">
        <p style="font-size:13px;color:var(--secondary-text);margin-bottom:16px;">
          聊天记录保存在本地浏览器中。网关服务端维护独立会话历史。
        </p>
      </div>
    `, `
      <button class="btn btn-danger" onclick="app.clearChatHistory()">清除本地聊天</button>
      <button class="btn btn-secondary" onclick="app.hideModal()">关闭</button>
    `);
  }

  clearChatHistory() {
    this.chatHistory = [];
    this.saveChatHistory();
    this.renderChat();
    this.hideModal();
    this.showToast('聊天记录已清除', 'success');
  }

  scrollToBottom(container) {
    if (!container) return;
    requestAnimationFrame(() => {
      container.scrollTop = container.scrollHeight;
    });
  }

  // ------------------------------------------
  // Memory Page
  // ------------------------------------------
  async renderMemories() {
    const tabsEl = document.getElementById('memory-tabs');
    const contentEl = document.getElementById('memory-content');
    if (!tabsEl || !contentEl) return;

    contentEl.innerHTML = '<div class="empty-text">加载中...</div>';

    try {
      const res = await fetch('/api/memories');
      if (!res.ok) throw new Error('Failed to load memories');
      const data = await res.json();

      const items = data.items || [];
      const stats = data.stats || {};

      // Render tabs
      const categories = [
        { key: '', label: '全部', count: items.length },
        { key: 'anniversary', label: '纪念日', count: stats.anniversary || 0 },
        { key: 'preference', label: '喜好', count: stats.preference || 0 },
        { key: 'promise', label: '约定', count: stats.promise || 0 },
        { key: 'story', label: '故事', count: stats.story || 0 },
        { key: 'password', label: '密码', count: stats.password || 0 },
        { key: 'travel', label: '旅行', count: stats.travel || 0 },
        { key: 'other', label: '其他', count: stats.other || 0 },
      ];

      tabsEl.innerHTML = categories.map(c => `
        <div class="memory-tab ${this.currentMemoryCategory === c.key ? 'active' : ''}"
             onclick="app.filterMemoryCategory('${c.key}')">
          ${c.label} <span class="tab-count">${c.count}</span>
        </div>
      `).join('');

      // Filter items
      const filtered = this.currentMemoryCategory
        ? items.filter(m => m.category === this.currentMemoryCategory)
        : items;

      if (filtered.length === 0) {
        contentEl.innerHTML = `
          <div class="empty-state">
            <div class="empty-icon">${svgIcon('memory', 'icon-xl')}</div>
            <p>暂无记忆</p>
            <button class="btn btn-primary btn-sm" onclick="app.showAddMemoryModal()">添加记忆</button>
          </div>
        `;
        return;
      }

      contentEl.innerHTML = `<div class="memory-grid">${filtered.map(m => `
        <div class="memory-card">
          <div class="memory-card-header">
            <span class="memory-date">${m.date || ''}</span>
            <button class="action-btn delete" onclick="app.deleteMemory('${m.id}')" title="删除">
              ${svgIcon('trash', 'icon-sm')}
            </button>
          </div>
          <div class="memory-card-body">
            <div class="memory-title">${this.escapeHtml(m.title || m.key || '')}</div>
            <div class="memory-content">${this.escapeHtml(m.content || '')}</div>
          </div>
        </div>
      `).join('')}</div>`;

    } catch (err) {
      contentEl.innerHTML = `<div class="empty-text">加载失败: ${this.escapeHtml(err.message)}</div>`;
    }
  }

  filterMemoryCategory(key) {
    this.currentMemoryCategory = key;
    this.renderMemories();
  }

  async searchMemories(query) {
    const contentEl = document.getElementById('memory-content');
    if (!contentEl) return;

    try {
      const res = await fetch(`/api/memories/search?q=${encodeURIComponent(query)}`);
      if (!res.ok) throw new Error('Search failed');
      const data = await res.json();
      const items = data.items || data.results || [];

      if (items.length === 0) {
        contentEl.innerHTML = '<div class="empty-text">未找到匹配的记忆</div>';
        return;
      }

      contentEl.innerHTML = `<div class="memory-grid">${items.map(m => `
        <div class="memory-card">
          <div class="memory-card-header">
            <span class="memory-date">${m.date || ''}</span>
            <button class="action-btn delete" onclick="app.deleteMemory('${m.id}')" title="删除">
              ${svgIcon('trash', 'icon-sm')}
            </button>
          </div>
          <div class="memory-card-body">
            <div class="memory-title">${this.escapeHtml(m.title || m.key || '')}</div>
            <div class="memory-content">${this.escapeHtml(m.content || '')}</div>
          </div>
        </div>
      `).join('')}</div>`;
    } catch (err) {
      contentEl.innerHTML = `<div class="empty-text">搜索失败: ${this.escapeHtml(err.message)}</div>`;
    }
  }

  showAddMemoryModal() {
    this.showModal('添加记忆', `
      <div class="form-group">
        <label>标题</label>
        <input type="text" id="mem-title" placeholder="记忆标题">
      </div>
      <div class="form-group">
        <label>内容</label>
        <textarea id="mem-content" rows="4" placeholder="记忆内容"></textarea>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>分类</label>
          <select id="mem-category">
            <option value="preference">喜好</option>
            <option value="anniversary">纪念日</option>
            <option value="promise">约定</option>
            <option value="story">故事</option>
            <option value="password">密码</option>
            <option value="travel">旅行</option>
            <option value="other">其他</option>
          </select>
        </div>
        <div class="form-group">
          <label>重要度 (0-1)</label>
          <input type="number" id="mem-importance" min="0" max="1" step="0.1" value="0.5">
        </div>
      </div>
    `, `
      <button class="btn btn-secondary" onclick="app.hideModal()">取消</button>
      <button class="btn btn-primary" onclick="app.saveNewMemory()">保存</button>
    `);
  }

  async saveNewMemory() {
    const title = document.getElementById('mem-title')?.value?.trim();
    const content = document.getElementById('mem-content')?.value?.trim();
    const category = document.getElementById('mem-category')?.value || 'other';
    const importance = parseFloat(document.getElementById('mem-importance')?.value) || 0.5;

    if (!title || !content) {
      this.showToast('请填写标题和内容', 'warning');
      return;
    }

    try {
      const res = await fetch('/api/memories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, key: title, content, category, importance })
      });
      if (!res.ok) throw new Error('Failed to save');
      this.hideModal();
      this.showToast('记忆已保存', 'success');
      this.renderMemories();
    } catch (err) {
      this.showToast(`保存失败: ${err.message}`, 'error');
    }
  }

  async deleteMemory(id) {
    if (!confirm('确定删除这条记忆？')) return;
    try {
      const res = await fetch(`/api/memories/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Failed to delete');
      this.showToast('已删除', 'success');
      this.renderMemories();
    } catch (err) {
      this.showToast(`删除失败: ${err.message}`, 'error');
    }
  }

  // ------------------------------------------
  // Reminders Page
  // ------------------------------------------
  async renderReminders() {
    const container = document.getElementById('reminders-content');
    if (!container) return;

    container.innerHTML = '<div class="empty-text">加载中...</div>';

    try {
      const res = await fetch('/api/reminders');
      if (!res.ok) throw new Error('Failed to load');
      const data = await res.json();
      const items = data.items || [];

      if (items.length === 0) {
        container.innerHTML = `
          <div class="empty-state">
            <div class="empty-icon">${svgIcon('bell', 'icon-xl')}</div>
            <p>暂无提醒</p>
            <button class="btn btn-primary btn-sm" onclick="app.showAddReminderModal()">创建提醒</button>
          </div>
        `;
        return;
      }

      container.innerHTML = items.map(r => {
        const statusClass = r.status === 'delivered' ? 'delivered' : 'pending';
        const statusLabel = r.status === 'delivered' ? '已送达' : '等待中';
        const triggerTime = r.trigger_at ? this.formatDateTime(new Date(r.trigger_at)) : '';

        return `
          <div class="reminder-item">
            <div class="list-icon">${svgIcon('bell')}</div>
            <div class="reminder-info">
              <div class="reminder-content">${this.escapeHtml(r.content)}</div>
              <div class="reminder-meta">${triggerTime}</div>
            </div>
            <span class="reminder-status ${statusClass}">${statusLabel}</span>
            <button class="action-btn delete" onclick="app.deleteReminder('${r.id}')" title="删除">
              ${svgIcon('trash', 'icon-sm')}
            </button>
          </div>
        `;
      }).join('');
    } catch (err) {
      container.innerHTML = `<div class="empty-text">加载失败: ${this.escapeHtml(err.message)}</div>`;
    }
  }

  showAddReminderModal() {
    this.showModal('创建提醒', `
      <div class="form-group">
        <label>提醒内容</label>
        <input type="text" id="rem-content" placeholder="提醒我做什么...">
      </div>
      <div class="form-group">
        <label>多少分钟后提醒</label>
        <input type="number" id="rem-minutes" min="1" value="30" placeholder="分钟">
      </div>
    `, `
      <button class="btn btn-secondary" onclick="app.hideModal()">取消</button>
      <button class="btn btn-primary" onclick="app.createNewReminder()">创建</button>
    `);
  }

  async createNewReminder() {
    const content = document.getElementById('rem-content')?.value?.trim();
    const minutes = parseInt(document.getElementById('rem-minutes')?.value) || 0;

    if (!content) {
      this.showToast('请填写提醒内容', 'warning');
      return;
    }
    if (minutes <= 0) {
      this.showToast('请输入有效的分钟数', 'warning');
      return;
    }

    try {
      const res = await fetch('/api/reminders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content, minutes })
      });
      if (!res.ok) throw new Error('Failed to create');
      this.hideModal();
      this.showToast('提醒已创建', 'success');
      this.renderReminders();
    } catch (err) {
      this.showToast(`创建失败: ${err.message}`, 'error');
    }
  }

  async deleteReminder(id) {
    try {
      const res = await fetch(`/api/reminders/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Failed to delete');
      this.showToast('已删除', 'success');
      this.renderReminders();
    } catch (err) {
      this.showToast(`删除失败: ${err.message}`, 'error');
    }
  }

  // ------------------------------------------
  // Settings Page
  // ------------------------------------------
  async renderSettings() {
    const statusEl = document.getElementById('settings-gateway-status');
    const contentEl = document.getElementById('settings-content');
    if (!contentEl) return;

    contentEl.innerHTML = '<div class="empty-text">加载中...</div>';

    let health = null;
    let config = null;
    let authExpired = false;

    try {
      const [hRes, cRes] = await Promise.all([
        this.apiFetch('/health'),
        this.apiFetch('/api/config')
      ]);
      if (hRes.ok) health = await hRes.json();
      if (cRes.ok) config = await cRes.json();
    } catch (err) {
      authExpired = err?.code === 'AUTH_REQUIRED';
    }

    if (!config) {
      contentEl.innerHTML = authExpired
        ? '<div class="empty-text">面板登录已失效，请刷新页面后重新输入密码。</div>'
        : '<div class="empty-text">无法连接到网关接口。更像是静态页面打开了，但 API 没通；请检查网关服务、反向代理和浏览器缓存。</div>';
      if (statusEl) statusEl.innerHTML = '';
      return;
    }

    this.gatewayConfig = config;

    // Gateway status
    if (statusEl) {
      const state = health?.state || {};
      const memCount = state.memory_count || 0;
      const sessions = state.runtime?.sessions || 0;
      const events = state.runtime?.events || 0;
      const toolCount = (state.enabled_tools || []).length;

      statusEl.innerHTML = `
        <div class="gateway-info-grid">
          <div class="gateway-info-item">
            <span class="gateway-info-label">状态</span>
            <span class="gateway-info-value" style="color: var(--success-dark);">在线</span>
          </div>
          <div class="gateway-info-item">
            <span class="gateway-info-label">记忆</span>
            <span class="gateway-info-value">${memCount}</span>
          </div>
          <div class="gateway-info-item">
            <span class="gateway-info-label">会话</span>
            <span class="gateway-info-value">${sessions}</span>
          </div>
          <div class="gateway-info-item">
            <span class="gateway-info-label">工具</span>
            <span class="gateway-info-value">${toolCount}</span>
          </div>
        </div>
      `;
    }

    // Settings sections
    contentEl.innerHTML = this.buildSettingsSections(config);
  }

  async refreshGatewayConfig() {
    this.showToast('刷新中...', 'info');
    await this.renderSettings();
    this.showToast('已刷新', 'success');
  }

  buildSettingsSections(c) {
    const persona = c.persona || {};
    const chatApi = c.chat_api || {};
    const actionApi = c.action_api || {};
    const searchApi = c.search_api || {};
    const ttsApi = c.tts_api || {};
    const imageApi = c.image_api || {};
    const memory = c.memory || {};
    const session = c.session || {};
    const scheduler = c.scheduler || {};
    const channels = c.channels || {};
    const dashboardSecurity = c.dashboard_security || {};

    return `
      <!-- Persona -->
      <div class="settings-section" id="sec-persona">
        <h4>${svgIcon('heart', 'icon-sm')} 人设</h4>
        <div class="setting-item">
          <label>伴侣名字</label>
          <input type="text" id="cfg-persona-partner_name" value="${this.escAttr(persona.partner_name || '')}">
        </div>
        <div class="setting-item">
          <label>伴侣角色</label>
          <input type="text" id="cfg-persona-partner_role" value="${this.escAttr(persona.partner_role || '')}">
        </div>
        <div class="setting-item">
          <label>对你的称呼</label>
          <input type="text" id="cfg-persona-call_user" value="${this.escAttr(persona.call_user || '')}">
        </div>
        <div class="setting-item">
          <label>核心气质</label>
          <textarea id="cfg-persona-core_identity" rows="3">${this.escapeHtml(persona.core_identity || '')}</textarea>
        </div>
        <div class="setting-item">
          <label>互动边界</label>
          <textarea id="cfg-persona-boundaries" rows="2">${this.escapeHtml(persona.boundaries || '')}</textarea>
        </div>
        <button class="btn btn-primary btn-block btn-save" onclick="app.saveSection('persona')">保存人设</button>
      </div>

      <!-- Chat API -->
      ${this.buildApiSection('chat_api', '聊天 API', 'chat', chatApi)}

      <!-- Action API -->
      ${this.buildActionApiSection(actionApi)}

      <!-- Search API -->
      ${this.buildApiSection('search_api', '搜索 API', 'search', searchApi)}

      <!-- TTS API -->
      ${this.buildApiSection('tts_api', 'TTS API', 'mic', ttsApi)}

      <!-- Image API -->
      ${this.buildApiSection('image_api', '图像 API', 'star', imageApi)}

      <!-- Memory -->
      <div class="settings-section" id="sec-memory">
        <h4>${svgIcon('memory', 'icon-sm')} 记忆系统</h4>
        <div class="setting-item toggle">
          <label>启用记忆</label>
          <label class="switch">
            <input type="checkbox" id="cfg-memory-enabled" ${memory.enabled ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </div>
        <button class="btn btn-primary btn-block btn-save" onclick="app.saveSection('memory')">保存</button>
      </div>

      <!-- Session -->
      <div class="settings-section" id="sec-session">
        <h4>${svgIcon('clock', 'icon-sm')} 会话</h4>
        <div class="setting-item toggle">
          <label>启用会话管理</label>
          <label class="switch">
            <input type="checkbox" id="cfg-session-enabled" ${session.enabled ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </div>
        <div class="setting-item">
          <label>空闲轮转 (分钟)</label>
          <input type="number" id="cfg-session-idle_rotation_minutes" value="${session.idle_rotation_minutes || 360}">
        </div>
        <div class="setting-item">
          <label>上下文消息数</label>
          <input type="number" id="cfg-session-recent_message_limit" value="${session.recent_message_limit || 12}">
        </div>
        <button class="btn btn-primary btn-block btn-save" onclick="app.saveSection('session')">保存</button>
      </div>

      <!-- Scheduler -->
      <div class="settings-section" id="sec-scheduler">
        <h4>${svgIcon('clock', 'icon-sm')} 调度器</h4>
        <div class="setting-item toggle">
          <label>启用调度器</label>
          <label class="switch">
            <input type="checkbox" id="cfg-scheduler-enabled" ${scheduler.enabled ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </div>
        <div class="setting-item toggle">
          <label>主动消息</label>
          <label class="switch">
            <input type="checkbox" id="cfg-scheduler-proactive_enabled" ${scheduler.proactive_enabled ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </div>
        <div class="setting-item">
          <label>主动消息空闲阈值 (小时)</label>
          <input type="number" id="cfg-scheduler-proactive_idle_hours" value="${scheduler.proactive_idle_hours || 72}">
        </div>
        <button class="btn btn-primary btn-block btn-save" onclick="app.saveSection('scheduler')">保存</button>
      </div>

      <!-- Channels -->
      <div class="settings-section" id="sec-channels">
        <h4>${svgIcon('chat', 'icon-sm')} 渠道</h4>
        <div class="setting-item toggle">
          <label>飞书</label>
          <label class="switch">
            <input type="checkbox" id="cfg-channels-feishu_enabled" ${channels.feishu_enabled ? 'checked' : ''}
                   onchange="app.toggleFeishuFields()">
            <span class="slider"></span>
          </label>
        </div>
        <div id="feishu-fields" style="display:${channels.feishu_enabled ? 'block' : 'none'};">
          <div class="setting-item">
            <label>App ID</label>
            <input type="text" id="cfg-channels-feishu_app_id" value="${this.escAttr(channels.feishu_app_id || '')}">
          </div>
          <div class="setting-item">
            <label>App Secret</label>
            <input type="password" id="cfg-channels-feishu_app_secret" value="${this.escAttr(channels.feishu_app_secret || '')}">
          </div>
        </div>

        <div class="setting-item toggle" style="margin-top:16px;">
          <label>QQ / NapCat</label>
          <label class="switch">
            <input type="checkbox" id="cfg-channels-napcat_enabled" ${channels.napcat_enabled ? 'checked' : ''}
                   onchange="app.toggleNapcatFields()">
            <span class="slider"></span>
          </label>
        </div>
        <div id="napcat-fields" style="display:${channels.napcat_enabled ? 'block' : 'none'};">
          <div class="setting-item">
            <label>NapCat Base URL</label>
            <input type="text" id="cfg-channels-napcat_base_url" value="${this.escAttr(channels.napcat_base_url || '')}" placeholder="http://127.0.0.1:3000">
          </div>
          <div class="setting-item">
            <label>Access Token</label>
            <input type="password" id="cfg-channels-napcat_access_token" value="${this.escAttr(channels.napcat_access_token || '')}" placeholder="OneBot token，可留空">
          </div>
          <div class="about-info" style="margin-bottom:12px;">建议使用 NapCat / OneBot v11 正向 HTTP API + 事件上报到网关 webhook。</div>
        </div>
        <button class="btn btn-primary btn-block btn-save" onclick="app.saveSection('channels')">保存</button>
      </div>

      <!-- Dashboard Security -->
      <div class="settings-section" id="sec-dashboard-security">
        <h4>${svgIcon('lock', 'icon-sm')} 面板密码</h4>
        <div class="setting-item toggle">
          <label>启用密码保护</label>
          <label class="switch">
            <input type="checkbox" id="cfg-dashboard-security-enabled" ${dashboardSecurity.enabled ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </div>
        <div class="setting-item">
          <label>新密码</label>
          <input type="password" id="cfg-dashboard-security-password" value="" placeholder="留空则不修改当前密码">
        </div>
        <div class="setting-item">
          <label>确认新密码</label>
          <input type="password" id="cfg-dashboard-security-password_confirm" value="" placeholder="再次输入新密码">
        </div>
        <div class="about-info" style="margin-bottom:12px;">默认密码是 admin123。修改密码后面板会自动刷新并要求重新登录。</div>
        <button class="btn btn-primary btn-block btn-save" onclick="app.saveSection('dashboard_security')">保存密码设置</button>
      </div>

      <!-- Theme -->
      <div class="settings-section">
        <h4>${svgIcon('star', 'icon-sm')} 主题</h4>
        <div class="theme-selector">
          ${['pink', 'blue', 'purple', 'green', 'orange'].map(t => `
            <div class="theme-option ${(localStorage.getItem('saki_theme') || 'pink') === t ? 'active' : ''}"
                 style="background: ${this.themePreviewColor(t)};"
                 onclick="app.setTheme('${t}')">
            </div>
          `).join('')}
        </div>
      </div>

      <!-- About -->
      <div class="settings-section">
        <h4>${svgIcon('info', 'icon-sm')} 关于</h4>
        <div class="about-info">
          <strong>咲手机 Gateway</strong><br>
          版本: 2.0.0<br>
          网关驱动的 AI 伴侣面板
        </div>
        <div class="setting-actions" style="margin-top:12px;">
          <button class="btn btn-danger btn-block" onclick="app.clearChatHistory(); app.showToast('聊天已清除','success');">清除本地聊天</button>
        </div>
      </div>
    `;
  }

  buildApiSection(key, label, icon, api) {
    return `
      <div class="settings-section" id="sec-${key}">
        <h4>${svgIcon(icon, 'icon-sm')} ${label}</h4>
        <div class="setting-item toggle">
          <label>启用</label>
          <label class="switch">
            <input type="checkbox" id="cfg-${key}-enabled" ${api.enabled ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </div>
        <div class="setting-item">
          <label>Base URL</label>
          <input type="text" id="cfg-${key}-base_url" value="${this.escAttr(api.base_url || '')}" placeholder="https://api.openai.com/v1">
        </div>
        <div class="setting-item">
          <label>API Key</label>
          <input type="password" id="cfg-${key}-api_key" value="${this.escAttr(api.api_key || '')}" placeholder="sk-...">
        </div>
        <div class="setting-item">
          <label>Model</label>
          <input type="text" id="cfg-${key}-model" value="${this.escAttr(api.model || '')}" placeholder="gpt-4o">
        </div>
        <button class="btn btn-primary btn-block btn-save" onclick="app.saveSection('${key}')">保存</button>
      </div>
    `;
  }

  buildActionApiSection(api) {
    return `
      <div class="settings-section" id="sec-action_api">
        <h4>${svgIcon('tool', 'icon-sm')} 工具执行 API</h4>
        <div class="setting-item toggle">
          <label>启用</label>
          <label class="switch">
            <input type="checkbox" id="cfg-action_api-enabled" ${api.enabled ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </div>
        <div class="setting-item">
          <label>Base URL</label>
          <input type="text" id="cfg-action_api-base_url" value="${this.escAttr(api.base_url || '')}" placeholder="https://api.openai.com/v1">
        </div>
        <div class="setting-item">
          <label>API Key</label>
          <input type="password" id="cfg-action_api-api_key" value="${this.escAttr(api.api_key || '')}" placeholder="sk-...">
        </div>
        <div class="setting-item">
          <label>Model</label>
          <input type="text" id="cfg-action_api-model" value="${this.escAttr(api.model || '')}" placeholder="gpt-4o-mini">
        </div>
        <div class="setting-item toggle">
          <label>启用 MCP</label>
          <label class="switch">
            <input type="checkbox" id="cfg-action_api-enable_mcp" ${api.enable_mcp ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </div>
        <button class="btn btn-primary btn-block btn-save" onclick="app.saveSection('action_api')">保存</button>
      </div>
    `;
  }

  toggleFeishuFields() {
    const enabled = document.getElementById('cfg-channels-feishu_enabled')?.checked;
    const fields = document.getElementById('feishu-fields');
    if (fields) fields.style.display = enabled ? 'block' : 'none';
  }

  toggleNapcatFields() {
    const enabled = document.getElementById('cfg-channels-napcat_enabled')?.checked;
    const fields = document.getElementById('napcat-fields');
    if (fields) fields.style.display = enabled ? 'block' : 'none';
  }

  async saveSection(section) {
    let payload = {};

    switch (section) {
      case 'persona':
        payload = {
          persona: {
            partner_name: this.getVal('cfg-persona-partner_name'),
            partner_role: this.getVal('cfg-persona-partner_role'),
            call_user: this.getVal('cfg-persona-call_user'),
            core_identity: this.getVal('cfg-persona-core_identity'),
            boundaries: this.getVal('cfg-persona-boundaries'),
          }
        };
        break;

      case 'chat_api':
      case 'action_api':
      case 'search_api':
      case 'tts_api':
      case 'image_api':
        if (section === 'action_api') {
          payload[section] = {
            enabled: this.getChecked('cfg-action_api-enabled'),
            base_url: this.getVal('cfg-action_api-base_url'),
            api_key: this.getVal('cfg-action_api-api_key'),
            model: this.getVal('cfg-action_api-model'),
            enable_mcp: this.getChecked('cfg-action_api-enable_mcp'),
          };
        } else {
          payload[section] = {
            enabled: this.getChecked(`cfg-${section}-enabled`),
            base_url: this.getVal(`cfg-${section}-base_url`),
            api_key: this.getVal(`cfg-${section}-api_key`),
            model: this.getVal(`cfg-${section}-model`),
          };
        }
        break;

      case 'memory':
        payload = {
          memory: {
            enabled: this.getChecked('cfg-memory-enabled'),
          }
        };
        break;

      case 'session':
        payload = {
          session: {
            enabled: this.getChecked('cfg-session-enabled'),
            idle_rotation_minutes: parseInt(this.getVal('cfg-session-idle_rotation_minutes')) || 360,
            recent_message_limit: parseInt(this.getVal('cfg-session-recent_message_limit')) || 12,
          }
        };
        break;

      case 'scheduler':
        payload = {
          scheduler: {
            enabled: this.getChecked('cfg-scheduler-enabled'),
            proactive_enabled: this.getChecked('cfg-scheduler-proactive_enabled'),
            proactive_idle_hours: parseInt(this.getVal('cfg-scheduler-proactive_idle_hours')) || 72,
          }
        };
        break;

      case 'channels':
        payload = {
          channels: {
            feishu_enabled: this.getChecked('cfg-channels-feishu_enabled'),
            feishu_app_id: this.getVal('cfg-channels-feishu_app_id'),
            feishu_app_secret: this.getVal('cfg-channels-feishu_app_secret'),
            napcat_enabled: this.getChecked('cfg-channels-napcat_enabled'),
            napcat_base_url: this.getVal('cfg-channels-napcat_base_url'),
            napcat_access_token: this.getVal('cfg-channels-napcat_access_token'),
          }
        };
        break;

      case 'dashboard_security': {
        const password = this.getVal('cfg-dashboard-security-password');
        const confirm = this.getVal('cfg-dashboard-security-password_confirm');
        if (password || confirm) {
          if (password.length < 4) {
            this.showToast('密码至少需要 4 位', 'warning');
            return;
          }
          if (password !== confirm) {
            this.showToast('两次输入的密码不一致', 'warning');
            return;
          }
        }
        payload = {
          dashboard_security: {
            enabled: this.getChecked('cfg-dashboard-security-enabled'),
          }
        };
        if (password) {
          payload.dashboard_security.password = password;
        }
        break;
      }

      default:
        return;
    }

    try {
      const res = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error('Save failed');
      if (section === 'dashboard_security') {
        this.showToast('密码设置已保存，正在刷新...', 'success');
        setTimeout(() => window.location.reload(), 800);
        return;
      }
      this.showToast('已保存', 'success');
    } catch (err) {
      this.showToast(`保存失败: ${err.message}`, 'error');
    }
  }

  // ------------------------------------------
  // Theme
  // ------------------------------------------
  setTheme(theme) {
    if (theme === 'pink') {
      document.body.removeAttribute('data-theme');
    } else {
      document.body.setAttribute('data-theme', theme);
    }
    localStorage.setItem('saki_theme', theme);

    // Update theme selector active state
    document.querySelectorAll('.theme-option').forEach(el => el.classList.remove('active'));
    // Re-render is simplest
    if (this.currentPage === 'settings') {
      this.renderSettings();
    }
  }

  applyTheme(theme) {
    if (theme && theme !== 'pink') {
      document.body.setAttribute('data-theme', theme);
    }
  }

  themePreviewColor(theme) {
    const map = {
      pink: '#F3E5E9',
      blue: '#E3EFF9',
      purple: '#EDE5F3',
      green: '#E5F3E9',
      orange: '#F3ECE5',
    };
    return map[theme] || '#F3E5E9';
  }

  // ------------------------------------------
  // Toast
  // ------------------------------------------
  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    container.appendChild(toast);

    requestAnimationFrame(() => {
      toast.classList.add('show');
    });

    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  // ------------------------------------------
  // Modal
  // ------------------------------------------
  showModal(title, bodyHtml, footerHtml = '') {
    const overlay = document.getElementById('modal-overlay');
    const titleEl = document.getElementById('modal-title');
    const bodyEl = document.getElementById('modal-body');
    const footerEl = document.getElementById('modal-footer');

    if (titleEl) titleEl.textContent = title;
    if (bodyEl) bodyEl.innerHTML = bodyHtml;
    if (footerEl) footerEl.innerHTML = footerHtml;

    if (overlay) {
      overlay.style.display = 'flex';
      requestAnimationFrame(() => overlay.classList.add('show'));
    }
  }

  hideModal() {
    const overlay = document.getElementById('modal-overlay');
    if (!overlay) return;
    overlay.classList.remove('show');
    setTimeout(() => {
      overlay.style.display = 'none';
    }, 300);
  }

  // ------------------------------------------
  // Utilities
  // ------------------------------------------
  escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
  }

  escAttr(str) {
    return (str || '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  formatTime(date) {
    if (!(date instanceof Date) || isNaN(date)) return '';
    return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
  }

  formatDate(date) {
    if (!(date instanceof Date) || isNaN(date)) return '';
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  }

  formatDateTime(date) {
    if (!(date instanceof Date) || isNaN(date)) return '';
    return `${this.formatDate(date)} ${this.formatTime(date)}`;
  }

  generateId() {
    return 'id_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
  }

  getVal(id) {
    const el = document.getElementById(id);
    return el ? (el.value || '') : '';
  }

  getChecked(id) {
    const el = document.getElementById(id);
    return el ? el.checked : false;
  }
}

// ============================================
// Bootstrap
// ============================================
window.app = new SakiPhoneApp();
